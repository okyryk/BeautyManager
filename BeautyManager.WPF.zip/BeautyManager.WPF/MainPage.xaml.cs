﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using Xamarin.Forms;
using Xamarin.Forms.Platform.WPF;

namespace BeautyManager.WPF
{
	/// <summary>
	/// Interaction logic for MainPage.xaml
	/// </summary>
	public partial class MainPage : FormsApplicationPage
	{
		public MainPage()
		{
			Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("NDYzNzU2QDMxMzkyZTMxMmUzMGxMcnFNVWxnL3R2YlVPSlpmalVGNEZ6cmpFMkJ0czhPN0ZIeUFSMEJnUGM9");
			InitializeComponent();
			this.Title = "$BeautyManager";
			Forms.Init();
			//SampleBrowser.Core.WPF.CoreSampleBrowser.Init();
			Syncfusion.SfSchedule.XForms.WPF.SfScheduleRenderer.Init();
			//Syncfusion.ListView.XForms.WPF.SfListViewRenderer.Init();
			Syncfusion.XForms.WPF.Border.SfBorderRenderer.Init();
			Syncfusion.XForms.WPF.Buttons.SfButtonRenderer.Init();
			LoadApplication(new BeautyManager.App());
		}
	}
}
